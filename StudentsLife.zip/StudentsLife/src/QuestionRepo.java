public class QuestionRepo {
public Question[] englishEasy = new Question[4];
public Question[] englishMedium1 = new Question[4];
public Question[] englishMedium2 = new Question[4];
public Question[] englishHard = new Question[4];
// **********************************
public Question[] mathEasy = new Question[4];
public Question[] mathMedium1 = new Question[4];
public Question[] mathMedium2 = new Question[4];
public Question[] mathHard = new Question[4];
// **********************************
public Question[] sciEasy = new Question[4];
public Question[] sciMedium1 = new Question[4];
public Question[] sciMedium2 = new Question[4];
public Question[] sciHard = new Question[4];
// **********************************
public Question[] csEasy = new Question[4];
public Question[] csMedium1 = new Question[4];
public Question[] csMedium2 = new Question[4];
public Question[] csHard = new Question[4];

String[] promptsEnglishEasy = {"Which is NOT a Shakespeare play?",
"Which is a noun?", "Which is NOT a synonym for teacher?",
"Which is an adverb?"
};
String[] promptsEnglishMedium1 = {"Which is a verb?",
"Which pronoun goes in the blank:\n Pushin P' and Vibez are my favourite songs because of ____ catchy beats",
"Which pronoun goes in the blank:\nAfter class, the principal talked to ____ and me.",
"Which is a synonym for test?"
};
String[] promptsEnglishMedium2 = {"Which is an incorrect contraction?",
"Which is an antonym for knowledgeable?",
"Which of the following is an alliteration?",
"Which of the following is an oxymoron?"
};
String[] promptsEnglishHard = {"What does pathos mean?",
"Which is NOT a type of irony?",
"Which Shakespeare play is the following quote from?\n'To thine own self be true.'",
"'These high heels are killing me.' is an example of a:"
};
String[] promptsMathEasy = {"What does '!' mean?",
"What is 5 ^ 3?", "What are the 3 basic trigonometric functions?",
"What is the derivative of 4 * x ^ 2?"
};
String[] promptsMathMedium1 = {"What is the slope of y = 2.5 * x + 32?",
"What is NOT a measure of center?", "Which of the following is an acute angle?",
"What is the total mumber of degrees in a triangle?"
};
String[] promptsMathMedium2 = {"Which is the correct formula for the area of a circle?",
"What is 270 degrees in radians?", "Which is the correct formula for the surface area of a sphere?",
"What is the approximate value of e?", "What is the second derivative of 10 * x ^ 3"
};
String[] promptsMathHard = {"Which is NOT a platonic solid?", "Which of the following is known as the harmonic series?",
"What is the indefinite integral of 3 * x ^2?", "What is the derivative of sin(2x)?"
};

String[] promptsSciEasy = {"What is known as the 'powerhouse of the cell'?",
"What is the 7th element on the periodic table?",
"How many electrons does hydrogen have?", "What kind of charge do protons have?","What 2 elements is table salt made up of?"
};
String[] promptsSciMedium1 = {"Which subatomic particle is the heaviest?","Which is a halogen?","What is C6H12O6 formula for?",
"What state of matter is iron in at room temperature?"
};
String[] promptsSciMedium2 = {"Which is a noble gas?",
"What is an isotope?",
"Which is NOT a type of mixture?",
"What is the approximate value of Avogadro's constant?"
};
String[] promptsSciHard = {"How many valence electrons does Chlorine have?", "What is the name of KI?", "Which is NOT a property of an ionic compound?",
"Which of the following is NOT a covalent bond?"
};
String[] promptsCsEasy = {"What does RAM stand for?", "What does volatile mean?", "Which is NOT a programming language?",
"How many bits are in a byte?", "In Java, which condition can never be true?"
};
String[] promptsCsMedium1 = {"What does ROM stand for?", "Is ROM non-volatile?", "How many bits are in a byte?",
"What does HTTP stand for?"
};
String[] promptsCsMedium2 = {"What is 1010 in decimal (base 10)?","What is C6 in decimal (base 10)?",
"Which declares a for loop correctly in Python?", "What does the error code 400 indicate?"

};
String[] promptsCsHard = {"Assuming you're coding in C in 64 bit architecture, how many bytes are in a double?",
"In Java, suppose x > 3. What is the value of x after the following statement? (x >= 2 ? x = 0 ; x *= 2)",
"Which condition can never be true?","What is the name of the class that all Java classes inherit (directly or indirectly) from?"
};
// **********************************
String[][] wrongEnglishEasy = {
{"Romeo and Juliet", "Hamlet", "Julius Caesar"},
{"bent", "restless", "skipping"},
{"instructor", "professor", "educator"},
{"hurry","firely","fastest"}
};
String[][] wrongEnglishMedium1 = {
{"devious", "material", "tutorial"},
{"there", "they're", "it's"},
{"they", "I", "she"},
{"grade", "recess", "homework"}
};
String[][] wrongEnglishMedium2 = {
{"isn't", "wasn't", "mustn't"},
{"skillful", "intelligent", "unknowledgeable"},
{"Mumbo Jumbo", "Kapow", "dumb genius"},
{"slept like a log", "super spicy salmon", "piece of cake"}
};
String[][] wrongEnglishHard = {
{"empathy", "humour", "patience"},
{"dramatic", "situational", "verbal"},
{"King Lear", "Othello", "The Tempest"},
{"simile", "idiom", "juxtaposition"}
};
String[][] wrongMathEasy = {
{"help", "factor", "sum"},
{"175", "166", "122"},
{"sit con, tas", "pi, gamma, beta", "sign, cose, tang"},
{"(4 / 3) * x ^ 3", "4 * x", "2 * x ^ 2"}
};
String[][] wrongMathMedium1 = {
{"2.5 * 32", "32", "2.5 * x"},
{"mean", "median", "mode"},
{"91", "181", "90"},
{"240", "90", "360"}
};
String[][] wrongMathMedium2 = {
{"pi * (r * 2)", "2 * pi * r", "r * pi ^ 2"},
{"pi / 2", "0", "2 * pi"},
{"(4 / 3) * pi * r ^ 3", "pi * r ^ 2", "4 * pi * r"},
{"2.718", "3.14", "2.178", "2.817"},
{"30 * x", "(10 / 3) * x ^ 2", "30 * x ^ 2"}
};
String[][] wrongMathHard = {
{"hexahedron", "pyramid", "icosahedron"},
{"1 / x ^ 2", "x ^ -3", "1 / (1 + x"},
{"6 * x + C", "(3 / 2) * x ^ 2 + C", "x ^ 3"},
{"2 * sin(2x)", "(1 / 2) cos (2x)", "sin(x)"}
};
String[][] wrongSciEasy = {
{"nucleus", "cell membrane", "mitosis"},
{"nickel", "carbon", "oxygen"},
{"2", "0", "4"},
{"negative", "neutral", "polar"},
{"sodium and fluorine", "chlorine and carbon", "table and salt"}
};
String[][] wrongSciMedium1 = {
{"proton", "electron", "ion"},
{"hydrogen","helium", "tellurium"},
{"carbon monoxide", "fructose", "carbonate"},
{"liquid", "gas", "plasma"}
};
String[][] wrongSciMedium2 = {
{"isn't", "wasn't", "mustn't"},
{"skillful", "intelligent", "unknowledgeable"},
{"Mumbo Jumbo", "Kapow", "dumb genius"},
{"slept like a log", "super spicy salmon", "piece of cake"}
};
String[][] wrongSciHard = {
{"17", "1", "2"},
{"potassium diodide", "ionic acid", "monopotassium iodine"},
{"high melting point", "water soluble", "brittle"},
{"simile", "idiom", "juxtaposition"}
};
String[][] wrongCsEasy = {
{"Read Only Memory", "Random Adding Machine", "Run All Morning"},
{"bent", "restless", "skipping"},
{"instructor", "professor", "educator"},
{"hurry","firely","fastest"}
};
String[][] wrongCsMedium1 = {
{"devious", "material", "tutorial"},
{"there", "they're", "it's"},
{"they", "I", "she"},
{"grade", "recess", "homework"}
};
String[][] wrongCsMedium2 = {
{"isn't", "wasn't", "mustn't"},
{"skillful", "intelligent", "unknowledgeable"},
{"Mumbo Jumbo", "Kapow", "dumb genius"},
{"slept like a log", "super spicy salmon", "piece of cake"}
};
String[][] wrongCsHard = {
{"4", "16", "64"},
{"6", "2", "4"},
{"x > 0 || x > 100", "!(x % 3 == 0)", "x <= 0 && x % 2 != 0"},
{"Exception", "Class", "Error"}
};
// *******************************
String[] correctEnglishEasy = {"Eleventh Night", "locker", "streamer", "slowly"};
String[] correctEnglishMedium1 = {"tutor", "their", "her", "assessment"};
String[] correctEnglishMedium2 = {"y'arent", "ignorant", "Papa's pizzeria", "pretty ugly"};
String[] correctEnglishHard = {"pity", "melodramatic", "Hamlet", "hyperbole"};
String[] correctMathEasy = {"factorial", "125", "sin, cos, tan", "8x"};
String[] correctMathMedium1 = {"2.5", "variance","35","180"};
String[] correctMathMedium2 = {"pi * r ^ 2", "(3 / 2) * pi", "4 * pi * r ^ 2", "2.718", "60 * x"};
String[] correctMathHard = {"heptahedron", "1/x", "x ^ 3 + C", "2 * cos(2x)"};
String[] correctSciEasy = {"mitochondria", "nitrogen", "1", "positive", "sodium and chlorine"};
String[] correctSciMedium1 = {"neutron", "iodine", "glucose", "solid"};
String[] correctSciMedium2 = {"", "ignorant", "Papa's pizzeria", "pretty ugly"};
String[] correctSciHard = {"7", "potassium iodide", "low melting point", "Li2S"};
String[] correctCsEasy = {"Random Access Memory", "memory is lost when power is turned off", "8", "x > 0 && x <= 0"};
String[] correctCsMedium1 = {"Read Only Memory", "yes", "her", "HyperText Transfer Protocol"};
String[] correctCsMedium2 = {"10", "198", "for i in range(n):", "bad request"};
String[] correctCsHard = {"8", "0", "x > 0 && x == 0", "Object"};

public QuestionRepo() {
for(int i = 0; i < 4; i++) {
englishEasy[i] = new Question(promptsEnglishEasy[i], wrongEnglishEasy[i], correctEnglishEasy[i]);
englishMedium1[i] = new Question(promptsEnglishMedium1[i], wrongEnglishMedium1[i], correctEnglishMedium1[i]);
englishMedium2[i] = new Question(promptsEnglishMedium2[i], wrongEnglishMedium2[i], correctEnglishMedium2[i]);
englishHard[i] = new Question(promptsEnglishHard[i], wrongEnglishHard[i], correctEnglishHard[i]);
mathEasy[i] = new Question(promptsMathEasy[i], wrongMathEasy[i], correctMathEasy[i]);
mathMedium1[i] = new Question(promptsMathMedium1[i], wrongMathMedium1[i], correctMathMedium1[i]);
mathMedium2[i] = new Question(promptsMathMedium2[i], wrongMathMedium2[i], correctMathMedium2[i]);
mathHard[i] = new Question(promptsMathHard[i], wrongMathHard[i], correctMathHard[i]);
sciEasy[i] = new Question(promptsSciEasy[i], wrongSciEasy[i], correctSciEasy[i]);
sciMedium1[i] = new Question(promptsSciMedium1[i], wrongSciMedium1[i], correctSciMedium1[i]);
sciMedium2[i] = new Question(promptsSciMedium2[i], wrongSciMedium2[i], correctSciMedium2[i]);
sciHard[i] = new Question(promptsSciHard[i], wrongSciHard[i], correctSciHard[i]);
csEasy[i] = new Question(promptsCsEasy[i], wrongCsEasy[i], correctCsEasy[i]);
csMedium1[i] = new Question(promptsCsMedium1[i], wrongCsMedium1[i], correctCsMedium1[i]);
csMedium2[i] = new Question(promptsCsMedium2[i], wrongCsMedium2[i], correctCsMedium2[i]);
csHard[i] = new Question(promptsCsHard[i], wrongCsHard[i], correctCsHard[i]);

}
}
}
