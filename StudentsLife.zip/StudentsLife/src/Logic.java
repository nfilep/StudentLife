import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class Logic {
	private String state = "";
	private BufferedImage title = Utils.loadImage("res/title.png"), teacher = Utils.loadImage("res/teacher.png"), 
			bg = Utils.loadImage("res/bg.png"), desk = Utils.loadImage("res/desk.png"), principaltex = Utils.loadImage("res/principal.png");
	private Point titlePos = new Point(0, 1000), teacherPos = new Point(5000, 100), wipeSize = new Point(1280, 960);
	private float opacity = 1f;
	private int page = 0;
	private List<Sprite> sprites = new ArrayList<>();
	private Font font = new Font("Courier New", 1, 30);
	private Game game;
	private Input input;
	private School school;
	private Timer nextClick = new Timer();
	
	public Logic(Game game) {
		this.game = game;
	}
	
	
	public void create() {
		sprites.add(new Sprite(principaltex, new Point(500, -1000)));
		input = new Input(this.game);
		school = new School(input);
		school.create();
	}
	
	public void update() {
		switch (state) {
		case "animating":
		case "tutorial":
			for (Sprite sprite : sprites) {
				sprite.update();
			}
			nextClick.update();
		break;
		case "game":
			school.update();
		break;
		}
	}
	
	public void render(Graphics2D g) {
		switch (state) {
			case "animating":
				introAnimation(g);
				for (Sprite sprite : sprites) {
					sprite.render(g);
				}
			break;
			case "tutorial":
				g.setFont(font);
				g.drawImage(bg, 0, 0, null, null);
				g.drawImage(desk, 0, 0, null, null);
				for (Sprite sprite : sprites) {
					sprite.render(g);
				}
				if (input.getButton() == (Integer)1 && nextClick.isFinished()) {
					page ++;
					nextClick.setTimer(100f);
					nextClick.start();
					if (page == 2) {
						sprites.get(sprites.size()-1).setDestination(900, 300, 0.05f);
						sprites.add(new Sprite(teacher, new Point(-500, 480)));
						sprites.get(sprites.size()-1).setDestination(540, 480, 0.05f);
					}
				}
				switch (page) {
					case 0:
						g.drawString("Welcome to STUDENTS LIFE highschool! I am your principal.", 40, 140);
						g.drawString("Allow me to guide you through the basics of highschool life", 40, 180);
						break;
					case 1:
						g.fillRect(170, 45, (int)(100*2.1f), 20);
						g.fillRect(568, 45, (int)(100*2.1f), 20);
						g.drawString("These meters represent your energy and happiness. They will", 40, 140);
						g.drawString("deplete over time, so you will have to drink coffee and", 40, 180);
						g.drawString("take breaks to replenish them.", 40, 220);
						break;
					case 2:
						g.fillRect(170, 45, (int)(100*2.1f), 20);
						g.fillRect(568, 45, (int)(100*2.1f), 20);
						g.setFont(new Font("Courier New", 1, 40));
						g.drawString("4.0", 1030, 70);
						g.setFont(font);
						g.drawString("This is your GPA. It will increase as you answer the", 40, 140);
						g.drawString("questions teachers and club members bring you correctly. See", 40, 180);
						g.drawString("how long you can go while keeping all of your stats up!", 40, 220);
						break;
					case 3:
						wipeSize.x += Utils.ease(wipeSize.x, 1500f, 0.02f);
						g.fillRect(0, 0, wipeSize.x, wipeSize.y);
						if (wipeSize.x <= 1500f) state = "game";
						break;
				}
				
			break;
			case "game":
				g.drawImage(bg, 0, 0, null, null);
				//
				school.render(g);
				//
				g.drawImage(desk, 0, 0, null, null);
			break;
		}
	}
	
	public void introAnimation(Graphics2D g) {
		if (!titlePos.equals(new Point(0, 0)))
			Utils.slide(title, titlePos, new Point(0, 0), g);
		if (titlePos.equals(new Point(0, 0)) && !teacherPos.equals(new Point(550, 100))) {
			g.drawImage(title, 0, 0, null, null);
		}
		if (!teacherPos.equals(new Point(550, 100)))
			Utils.slide(teacher, teacherPos, new Point(550, 100), g);
		if (titlePos.equals(new Point(0, 0)) && teacherPos.equals(new Point(550, 100))) {
			 if (opacity > 0.01) { 
				 opacity -= 0.0025f;
				 g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, opacity));
				 g.drawImage(title, 0, 0, null, null);
				 g.drawImage(teacher, 550, 100, null, null);
			 }
			 else {
				 g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1));
				 g.drawImage(bg, 0, 0, null, null);
				 g.drawImage(desk, 0, 0, null, null);
				 sprites.get(sprites.size()-1).setDestination(500, 300, 0.01f);
				 g.setColor(Color.WHITE);
				 wipeSize.x += Utils.ease(wipeSize.x, 0f, 0.02f);
				 g.fillRect(0, 0, wipeSize.x, wipeSize.y);
				 if (wipeSize.x <= 0.0f) state = "tutorial";
			 }
		}
	}
	
	public void setState(String state) {
		this.state = state;
	}
}
