import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferStrategy;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class Game extends Canvas implements Runnable {

	private static final int WIDTH = 1280, HEIGHT = 960;
	
 	private boolean running = false;
	
 	private Thread thread;
	private Camera camera;
	private static Logic gameLogic;
	private static Game game = new Game();
	private static JFrame gui;
	
	public static void main (String [] args) {
		window();
		game.start();
	}
	
	public void create() {
 		gameLogic = new Logic(this);
 		gameLogic.create();
 		camera = new Camera(0, 0);
	}
	
	public static void window() {
		gui = new JFrame();
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    gui.setSize(WIDTH,HEIGHT);
	    gui.setTitle("Window");
	    gui.setLocationRelativeTo(null);
	    gui.setResizable(false);
	    
	    JPanel panel = new JPanel();
	    gui.getContentPane();
	    JButton startButton = new JButton();
	    startButton.setIcon(new ImageIcon("res/start.png"));
	    startButton.setBackground(Color.WHITE);
	    startButton.setBorderPainted(false);
	    startButton.setFocusable(false);
	    JButton multiplayerbutton = new JButton();
	    multiplayerbutton.setIcon(new ImageIcon("res/multiplayer.png"));
	    multiplayerbutton.setBackground(Color.WHITE);
	    multiplayerbutton.setBorderPainted(false);
	    multiplayerbutton.setFocusable(false);
	    startButton.addActionListener(new ActionListener() { 
	          public void actionPerformed(ActionEvent e) {
	            gui.remove(panel);
	            gameLogic.setState("animating");
	          }
	    });
	    Dimension size = startButton.getPreferredSize();
	    startButton.setBounds(270, 620, size.width, size.height);
	    size = multiplayerbutton.getPreferredSize();
	    multiplayerbutton.setBounds(270, 740, size.width, size.height);
	    panel.setLayout(null);
	    panel.add(startButton);
	    panel.add(multiplayerbutton);
	    panel.setBackground(Color.WHITE);
	    panel.setBounds(100, 100, 100, 100);
	    panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
	    panel.setLayout(new GridLayout(0, 1));
        
        gui.add(panel);
	    gui.setVisible(true);
	    gui.add(game);
	}
	
	public synchronized void start() {
	  if (this.running) {
	    return;
	  }
	  this.running = true;
	  this.thread = new Thread(this);
	  this.thread.start();
	}
	
	private synchronized void stop() {
	  if (!this.running) {
	    return;
	  }
	  this.running = false;
	  try {
	    this.thread.join();
	  } catch (InterruptedException e) {
	    e.printStackTrace();
	  } 
	  System.exit(1);
	}
	
	public void run() {
	  create();
	  long lastTime = System.nanoTime();
	  double ns = 1.6666666666666666E7D;
	  double delta = 0.0D;
	  long timer = System.currentTimeMillis();
	  
	  while (this.running) {
	    long now = System.nanoTime();
	    delta += (now - lastTime) / ns;
	    lastTime = now;
	    if (delta >= 1.0D) {
	      update();
	      delta--;
	    } 
	    render();
	    if (System.currentTimeMillis() - timer > 1000L) {
	      timer += 1000L;
	    } 
	  } 
	  stop();
	}

	private void update() {
		gameLogic.update();
	}

	private void render() {
		BufferStrategy bs = this.getBufferStrategy();		
		if (bs == null) {
			createBufferStrategy(3);
			return;
		}
		Graphics2D g = (Graphics2D) bs.getDrawGraphics();
		
			g.translate(camera.x(), camera.y());
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, 1280, 960);
			gameLogic.render(g);
			g.translate(camera.x(), camera.y());
			
		g.dispose();
		bs.show();
	}
}