import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.image.BufferedImage;

public class Sprite {
	private BufferedImage texture;
	private Point pos;
	private Point dest = new Point();
	private float angle = 0f, ease = 0.01f;
	
	public Sprite (BufferedImage texture, Point pos) {
		this.texture = texture;
		this.pos = pos;
		dest.setLocation(pos);
	}
	
	public void update() {
		pos.y -= (int) (2*Math.sin(angle));
		angle += 0.1f;
		if (!pos.equals(dest)) {
			pos.y += Utils.ease(pos.y, dest.y, ease);
			pos.x += Utils.ease(pos.x, dest.x, ease);
		}
	}
	
	public void render(Graphics2D g) {
		g.drawImage(texture, pos.x, pos.y, null, null);
	}
	
	public void setDestination(int x, int y, float ease) {
		this.dest.x = x;
		this.dest.y = y;
		this.ease = ease;
	}
	
	public BufferedImage getTexture() {
		return texture;
	}
	
}
