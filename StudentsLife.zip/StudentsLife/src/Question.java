import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;

public class Question {
	private String prompt;
	private String[] options;
	private int answerID;
	
	public Question(String prompt, String[] incorrectAnswers, String correctAnswer) {
		this.prompt = prompt;
		this.options = new String[4];
		this.answerID = (int)(Math.random() * 4);
		options[answerID] = correctAnswer;
		int index = 0;
		for(int i = 0; i < options.length; i++) {
			if(i != answerID) {
				options[i] = incorrectAnswers[index];
				index++;
			}
		}
	}
	
	public boolean checkAnswer(int id) {
		return id == answerID;
	}
	
	public int getAnswerID() {
		return answerID;
	}
	
	public void render(Graphics2D g) {
		g.setColor(Color.WHITE);
		g.setFont(new Font("Courier New", 1, 30));
		g.drawString(prompt, 80, 410);
		for(int i = 0; i < options.length; i++) {
			g.drawString((char)(65+i) + ": " + options[i], 80, i*50+510);
		}
	}
	
	public void display() {
		System.out.println(prompt);
		for(int i = 0; i < options.length; i++) {
			System.out.println((char)(65+i) + ": " + options[i]);
		}
	}
}