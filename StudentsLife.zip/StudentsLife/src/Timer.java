
public class Timer {
	private float timer;
	private boolean counting = false;
	
	public void update() {
		if (counting && timer >= 0.01) {
			timer --;
		}
	}
	
	public void setTimer(float timer){
		this.timer = timer;
	}
	
	public boolean isFinished() {
		if (timer <= 0.01) return true;
		return false;
	}
	
	public void start() {
		this.counting = true;
	}
	
	public void stop() {
		this.counting = false;
	}
	
	public float getTimer() {
		return timer;
	}
}
