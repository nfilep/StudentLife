import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class Input {
	private Integer key = null, button = null;
	private Point pos = new Point();
	
	public Input(Game game) {
		game.addKeyListener(new KeyListener() {
			@Override
			public void keyPressed(KeyEvent e) {
				key = e.getKeyCode();
    		}
			@Override
    		public void keyReleased(KeyEvent e) {
				key = null;
    		}
			@Override
    		public void keyTyped(KeyEvent e) {
    		}
    	});
		
		game.addMouseMotionListener(new MouseMotionListener() {
			@Override
			public void mouseDragged(MouseEvent e) {
			}
			@Override
			public void mouseMoved(MouseEvent e) {
				pos = e.getPoint();
			}
    	});
		
		game.addMouseListener(new MouseListener() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
			@Override
			public void mouseEntered(MouseEvent e) {
			}
			@Override
			public void mouseExited(MouseEvent e) {
			}
			@Override
			public void mousePressed(MouseEvent e) {
				button = e.getButton(); 
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				button = null;
			}
    	});
	}
	
	public Integer getKey() {
		return key;
	}
	
	public Integer getButton() {
		return button;
	}
	
	public Point getPos() {
		return pos;
	}
}
