import java.io.IOException;

public class Period {
	private int year;
	private Question[][] questions = new Question[4][4];
	private QuestionRepo repo = new QuestionRepo();
	int rng = 0;
	int[] indexes = new int[4];
	
	
	public Period(int year) {
		this.year = year;
		rng = (int)(Math.random() * 4);
		for(int i = 0; i < 4; i++) {
			indexes[i] = rng;
			rng = (rng - 1 + 4) % 4;
			//System.out.println(indexes[i]);
		}
		try{
			switch(year) {
			case 0:
				//for(int i = 0; i < 4; i++) {
					questions[indexes[0]] = repo.englishEasy;
					//System.out.println("English Easy: " + indexes[0]);
					questions[indexes[1]] = repo.mathEasy;
					questions[indexes[2]] = repo.sciEasy;
					questions[indexes[3]] = repo.csEasy;
				//}
				break;
			case 1:
				//for(int i = 0; i < 4; i++) {
					questions[indexes[0]] = repo.englishMedium1;
					//System.out.println("English Medium1: " + indexes[i]);
					questions[indexes[1]] = repo.mathMedium1;
					questions[indexes[2]] = repo.sciMedium1;
					questions[indexes[3]] = repo.csMedium1;
				//}
				break;
			case 2:
				//for(int i = 0; i < 4; i++) {
					questions[indexes[0]] = repo.englishMedium2;
					//System.out.println("English Medium2: " + indexes[i]);
					questions[indexes[1]] = repo.mathMedium2;
					questions[indexes[2]] = repo.sciMedium2;
					questions[indexes[3]] = repo.csMedium2;
				//}
				break;
			case 3:
				//for(int i = 0; i < 4; i++) {
					questions[indexes[0]] = repo.englishHard;
					//System.out.println("English Hard: " + indexes[i]);
					questions[indexes[1]] = repo.mathHard;
					questions[indexes[2]] = repo.sciHard;
					questions[indexes[3]] = repo.csHard;
				//}
				break;
			default:
				throw new IOException();
			}
		} catch(IOException e) {
			System.out.println("Incorrect year level: " + year);
		}
	}
	
	public Question[] getCurrYear(int year) {
		return questions[year];
	}
	
	public Question getCurrQuestion(int sub, int numQ) {
		return questions[sub][numQ];
	}
	
	public String getSubject(int sub) {
		int i = indexID(sub);
		switch(i){
		case 0:
		return "English";
		case 1:
		return "Math";
		case 2:
		return "Science";
		case 3:
		return "Computer Science";
		default:
		return "NAN";
		}
		}

		private int indexID(int sub) {
			for(int i = 0; i < 4; i++) {
				if(indexes[i] == sub) {
					return i;
				}
			}
			return -1;
		}
	/*
	public void displayCurrQuestion(int year, int sub, int numQ) {
		questions[year][sub][numQ].display();
	}*/
}
