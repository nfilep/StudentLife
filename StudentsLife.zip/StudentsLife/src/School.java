import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

public class School {
	final int[] questionsPerLevel = {4,4,4,4};
	final double[] gpaDecAmt = {0.25,0.5,0.75,1.00};
	final int numTeachers = 4;
	int rng = (int)(Math.random() * 4 + 1), numCompleted = 0, currYear = 0, currSub = 0;
	float caffPercent = 100f, hapPercent = 100f, gpa = 4.0f;
	Timer nextQ = new Timer(), coffeeTimer = new Timer();
	Question currQ;
	Period[] allYears = new Period[4];
	private boolean won = false, askedQuestion = false;
	private Input input;
	private List<Sprite> sprites = new ArrayList<>();
	private BufferedImage teacher = Utils.loadImage("res/teacher.png"), 
			clubMember = Utils.loadImage("res/clubmember.png"), coffee = Utils.loadImage("res/coffee.png"), gameOver = Utils.loadImage("res/gameover.png");
	private Rectangle coffeeBounds = new Rectangle();
	
	public School(Input input) {
		for(int i = 0; i < 4; i ++) {
			allYears[i] = new Period(i);
		}
		coffeeBounds.setBounds(1000, 300, coffee.getWidth(), coffee.getHeight());
		this.input = input;
	}
	
	
	
	public void create() {
		nextQ.setTimer(50f);
		rng = (int)(Math.random() * 4 + 1);
		if (rng == 1) {
			sprites.add(new Sprite(clubMember, new Point(-500, 500)));
			sprites.get(sprites.size()-1).setDestination(595, 500, 0.05f);
		}
		else {
			sprites.add(new Sprite(teacher, new Point(-500, 480)));
			sprites.get(sprites.size()-1).setDestination(540, 480, 0.05f);
		}
		
		askedQuestion = true;
	}
	
	public void update() {
		if (gpa > 0 && hapPercent > 0 && caffPercent > 0 && currYear < 3) {
			hapPercent -= 0.02f;
			caffPercent  -= 0.02f;
			if (askedQuestion) {
				currQ = allYears[currYear].getCurrQuestion(currSub, numCompleted);
				askedQuestion = false;
			}
			
			if (input.getButton()!=null) {
				if (input.getButton() == 1 && coffeeBounds.contains(input.getPos()) && coffeeTimer.isFinished() && caffPercent < 75) {
					caffPercent += 16;
					coffeeTimer.setTimer(600f);
					coffeeTimer.start();
				}
			}
			coffeeTimer.update();
			
			if (input.getKey() != null && currQ != null) {
				if (input.getKey() == currQ.getAnswerID()+65) {
					if(gpa < 4.0) gpa = (float) Math.min(4.0, gpa + gpaDecAmt[currYear]);
					if (sprites.get(sprites.size()-1).getTexture().equals(clubMember))	if(hapPercent < 100) hapPercent += 16;
					sprites.get(sprites.size()-1).setDestination(2000, 480, 0.01f);
				}
				else {
					gpa = (float) Math.max(0.0, gpa - gpaDecAmt[currYear]);
					sprites.get(sprites.size()-1).setDestination(-600, 480, 0.01f);
				}
				numCompleted++;
				if (numCompleted >= 4) {
					numCompleted = 0;
					currSub ++;
				}
				if (currSub >= 4) {
					currSub = 0;
					currYear ++;
				}
				nextQ.start();
				currQ = null;
			}
			if (nextQ.isFinished()) {
				nextQ.stop();
				create();
			}
			nextQ.update();
			for (Sprite sprite : sprites) {
				sprite.update();
			}
		}
	}
	
	public void render(Graphics2D g) {
		for (Sprite sprite : sprites) {
			sprite.render(g);
		}
		//
		g.setColor(Color.GREEN);
		g.fillRect(170, 45, (int)(caffPercent*2.1f), 20);
		g.fillRect(568, 45, (int)(hapPercent*2.1f), 20);
		g.fillRect(970, 450, (int)(coffeeTimer.getTimer()/4), 10);
		g.setFont(new Font("Courier New", 1, 40));
		g.drawString(""+gpa, 1030, 70);
		g.drawString("Period: " + allYears[currYear].getSubject(currSub), 80, 150);
		g.drawString("Year: " + (currYear+1), 80, 220);
		g.drawString("Completed: " + numCompleted, 80, 290);
		g.drawImage(coffee, 1000, 300, null, null);
		if (currQ != null)
			currQ.render(g);
		
		if(gpa <= 0) {
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, 1280, 960);
			g.setColor(Color.RED);
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
			g.drawImage(gameOver, 0, 0, null, null);
			g.setFont(new Font("Courier New", 1, 40));
			g.drawString("Study Harder!", 320, 600);
		}else if(caffPercent <= 0) {
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, 1280, 960);
			g.setColor(Color.RED);
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
			g.drawImage(gameOver, 0, 0, null, null);
			g.setFont(new Font("Courier New", 1, 40));
			g.drawString("Wake Up!", 320, 600);
		}else if(hapPercent <= 0){
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, 1280, 960);
			g.setColor(Color.RED);
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 1f));
			g.drawImage(gameOver, 0, 0, null, null);
			g.setFont(new Font("Courier New", 1, 40));
			g.drawString("Don't worry, be happy :)", 320, 600);
		}else if (currYear >= 4) {
			sprites.add(new Sprite(Utils.loadImage("res/win.png"), new Point(0, 0)));
			
		}
	}
	
}
