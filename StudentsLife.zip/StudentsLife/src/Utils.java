import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Utils {
	
	private static List<Clip> clips = new ArrayList<>();
	
	public static void slide(BufferedImage img, Point pos, Point targ, Graphics2D g) {
		pos.x += Utils.ease(pos.x, targ.x, 0.02f);
		pos.y += Utils.ease(pos.y, targ.y, 0.02f);
		g.drawImage(img, pos.x, pos.y, null, null);
}
	
	public static float ease(float start, float end, float ease) {
		return (end-start)*ease;
	}
	
	public static BufferedImage loadImage(String path) {
		try {
			return ImageIO.read(new File(path));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void playAudio(String path){
		try {
			AudioInputStream audioStream = AudioSystem.getAudioInputStream(new File(path));
			Clip clip = AudioSystem.getClip();
			clips.add(clip);
			clip.open(audioStream);
			clip.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void loopAudio(String path){
		try {
			AudioInputStream audioStream = AudioSystem.getAudioInputStream(new File(path));
			Clip clip = AudioSystem.getClip();
			clips.add(clip);
			clip.open(audioStream);
			clip.loop(Clip.LOOP_CONTINUOUSLY);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void stopAllClips() {
		for (Clip clip: clips) {
			clip.stop();
		}
	}
}
